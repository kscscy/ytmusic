package java76.pms.dao;

import java.util.List;
import java.util.Map;

import java76.pms.domain.Music;

public interface MusicDao {
  List<Music> selectList(Map<String,Object> paramMap);
  
  int insert(Music music);
  
  int delete(Map<String,Object> paramMap);
  
  int update(Music music);

  Music selectOne(int no);
}







